
public abstract class Shape {
	private final String color;
	
	public Shape(String color) {
		this.color = color;
	}
	
	public Shape() {
		this.color = null;
	}
	
	
}
